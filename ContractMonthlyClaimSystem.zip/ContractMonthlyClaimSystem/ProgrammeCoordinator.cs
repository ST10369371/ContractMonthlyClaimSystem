﻿namespace ContractMonthlyClaimSystem
{
    public class ProgrammeCoordinator
    {
        public int ProgrammeCoordinatorId { get; set; }
        public string Name { get; set; }
    }
}
