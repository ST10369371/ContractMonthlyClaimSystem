﻿namespace ContractMonthlyClaimSystem
{
    public class AcademicManager
    {
        public int AcademicManagerId { get; set; }
        public string Name { get; set; }
    }

}
