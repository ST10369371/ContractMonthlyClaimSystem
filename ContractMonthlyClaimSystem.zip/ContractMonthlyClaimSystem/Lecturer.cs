﻿using System.Security.Claims;

namespace ContractMonthlyClaimSystem
{
    public class Lecturer
    {
        public int LecturerId { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }
        public ICollection<Claim> Claims { get; set; }
    }
}
